#include <iostream>

using namespace std;

int main()
{
    int i = 0;
    while (i < 10)
    {
        cout << i;
        i++;
    }
    return 0;
}
