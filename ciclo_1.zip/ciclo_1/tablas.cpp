#include <iostream>

using namespace std;

int main()
{
    int i = 1;
    while (i < 13)
    {
        cout << "12 x " << i << " = " << i * 12 << "\n";
        i++;
    }
    return 0;
}
